<header class="header">
    <div class="container">
        <div class="menu">
            <div class="logo">
                <img src="<?php echo e(asset('images/cropped-Logo_AstroverseClub_04-1.png')); ?>" alt="Logo">
            </div>
            <div class="navbar">
                <ul>
                    <li class=""><a href="/">Home</a></li>
                    <li class=""><a href="">About</a></li>
                    <li class=""><a href="">Service</a></li>
                    <?php if(auth()->guard()->guest()): ?>
                        <li class=""><a href="login">Login</a></li>
                        <li class=""><a href="register">Register</a></li>
                    <?php endif; ?>

                    <?php if(auth()->guard()->check()): ?>
                        <li class=""><a href="dashboard"><?php echo e(auth()->user()->name); ?></a></li>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            

                            <button type="submit" style="background: transparent;
    border: none;
    color: white;
    font-size: inherit;cursor: pointer">
                                <?php echo e(__('Log Out')); ?>

                            </button>
                        </form>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</header>
<?php /**PATH /home/behlole/Desktop/fitness/Fitness/resources/views/parts/header.blade.php ENDPATH**/ ?>