<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('parts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="legs-exercise">
        <div class="container">
            <div class="exercise">
                <h1 class="arm-main-heading">
                    Easy Legs Exercises You Can Do At Home
                </h1>
                <div class="e1">
                    <div class="e-text e1-text">
                        <h1>
                            Squats
                        </h1>
                        <p>
                            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Amet nulla in explicabo ratione
                            fugit iusto dolorum iste perferendis incidunt dolor deserunt laudantium ipsam quas, ducimus,
                            minima harum quod nostrum voluptatum?
                        </p>
                        <ul>
                            <li> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad sequi expedita quis
                                delectus, odio qui consequuntur rem accusamus distinctio dolor libero, ullam error
                                obcaecati animi? Commodi consequuntur saepe nemo architecto!
                            </li>
                            <li> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad sequi expedita quis
                                delectus, odio qui consequuntur rem accusamus distinctio dolor libero, ullam error
                                obcaecati animi? Commodi consequuntur saepe nemo architecto!
                            </li>
                            <li> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad sequi expedita quis
                                delectus, odio qui consequuntur rem accusamus distinctio dolor libero, ullam error
                                obcaecati animi? Commodi consequuntur saepe nemo architecto!
                            </li>
                            <li> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad sequi expedita quis
                                delectus, odio qui consequuntur rem accusamus distinctio dolor libero, ullam error
                                obcaecati animi? Commodi consequuntur saepe nemo architecto!
                            </li>
                            <li> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad sequi expedita quis
                                delectus, odio qui consequuntur rem accusamus distinctio dolor libero, ullam error
                                obcaecati animi? Commodi consequuntur saepe nemo architecto!
                            </li>
                        </ul>
                    </div>
                    <div class="e-img e1-img">
                        <img src="<?php echo e(asset('images/squats.jpg')); ?>" alt="arm-circles">
                    </div>
                </div>
                <div class="e-iframe">
                    <iframe width="560" height="315" src="https://www.youtube.com/embed/bP52FXTlzjA?controls=0"
                            title="YouTube video player" frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowfullscreen></iframe>
                </div>
                <div class="e2">
                    <div class="e-img e2-img">
                        <img src="<?php echo e(asset('images/wallsits.jpg')); ?>" alt="arm-circles">
                    </div>
                    <div class="e-text e2-text">
                        <h1>
                            Wall Sits
                        </h1>
                        <p>
                            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Amet nulla in explicabo ratione
                            fugit iusto dolorum iste perferendis incidunt dolor deserunt laudantium ipsam quas, ducimus,
                            minima harum quod nostrum voluptatum?
                        </p>
                        <ul>
                            <li> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad sequi expedita quis
                                delectus, odio qui consequuntur rem accusamus distinctio dolor libero, ullam error
                                obcaecati animi? Commodi consequuntur saepe nemo architecto!
                            </li>
                            <li> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad sequi expedita quis
                                delectus, odio qui consequuntur rem accusamus distinctio dolor libero, ullam error
                                obcaecati animi? Commodi consequuntur saepe nemo architecto!
                            </li>
                            <li> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad sequi expedita quis
                                delectus, odio qui consequuntur rem accusamus distinctio dolor libero, ullam error
                                obcaecati animi? Commodi consequuntur saepe nemo architecto!
                            </li>
                            <li> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad sequi expedita quis
                                delectus, odio qui consequuntur rem accusamus distinctio dolor libero, ullam error
                                obcaecati animi? Commodi consequuntur saepe nemo architecto!
                            </li>
                            <li> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad sequi expedita quis
                                delectus, odio qui consequuntur rem accusamus distinctio dolor libero, ullam error
                                obcaecati animi? Commodi consequuntur saepe nemo architecto!
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="e-iframe">
                    <iframe width="560" height="315" src="https://www.youtube.com/embed/c3ZGl4pAwZ4?controls=0"
                            title="YouTube video player" frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowfullscreen></iframe>
                </div>
                <div class="e3">
                    <div class="e-text e3-text">
                        <h1>
                            Leg Raises
                        </h1>
                        <p>
                            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Amet nulla in explicabo ratione
                            fugit iusto dolorum iste perferendis incidunt dolor deserunt laudantium ipsam quas, ducimus,
                            minima harum quod nostrum voluptatum?
                        </p>
                        <ul>
                            <li> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad sequi expedita quis
                                delectus, odio qui consequuntur rem accusamus distinctio dolor libero, ullam error
                                obcaecati animi? Commodi consequuntur saepe nemo architecto!
                            </li>
                            <li> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad sequi expedita quis
                                delectus, odio qui consequuntur rem accusamus distinctio dolor libero, ullam error
                                obcaecati animi? Commodi consequuntur saepe nemo architecto!
                            </li>
                            <li> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad sequi expedita quis
                                delectus, odio qui consequuntur rem accusamus distinctio dolor libero, ullam error
                                obcaecati animi? Commodi consequuntur saepe nemo architecto!
                            </li>
                            <li> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad sequi expedita quis
                                delectus, odio qui consequuntur rem accusamus distinctio dolor libero, ullam error
                                obcaecati animi? Commodi consequuntur saepe nemo architecto!
                            </li>
                            <li> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad sequi expedita quis
                                delectus, odio qui consequuntur rem accusamus distinctio dolor libero, ullam error
                                obcaecati animi? Commodi consequuntur saepe nemo architecto!
                            </li>
                        </ul>
                    </div>
                    <div class="e-img e3-img">
                        <img src="<?php echo e(asset('images/legraises.png')); ?>" alt="arm-circles">
                    </div>
                </div>
                <div class="e-iframe">
                    <iframe width="560" height="315" src="https://www.youtube.com/embed/IODxDxX7oi4?controls=0"
                            title="YouTube video player" frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/behlole/Desktop/fitness/Fitness/resources/views/pages/legs.blade.php ENDPATH**/ ?>