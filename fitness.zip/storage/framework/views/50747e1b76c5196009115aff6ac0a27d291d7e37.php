<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fitness</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>

<body>
<?php echo $__env->yieldContent('content'); ?>
</body>

</html>
<?php /**PATH /home/behlole/FitnessLaravel/Fitness/resources/views/layout/main.blade.php ENDPATH**/ ?>