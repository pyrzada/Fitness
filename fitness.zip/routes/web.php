<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/legs', function () {
    return view('pages.legs');
});
Route::get('/chest', function () {
    return view('pages.chest');
});
Route::get('/abs', function () {
    return view('pages.abdomen');
});
Route::get('/arms', function () {
    return view('pages.arms');
});

Route::get('/weekly', function () {
    return view('pages.weekly');
})->middleware('auth');
Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth'])->name('dashboard');

require __DIR__ . '/auth.php';
